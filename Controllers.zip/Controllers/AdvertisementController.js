﻿var app = angular.module("dashboardApp");

app.controller("AdvertisementController", function ($scope, $http) {

    $scope.text = "working";

    $scope.advertisements = [];
    $scope.getAdvertisements = function () {
        $http.post("https://api-rubtech.designaccentindia.com/Advertisement/GetAdvertisement")
            .then(function (response) {
                console.log("API Response:", response.data);

                if (Array.isArray(response.data)) {
                    $scope.advertisements = response.data.map(ad => ({
                        ID: ad.Id,
                        URL:ad.URL,
                        ImagePath: ad.ImagePath
                            ? "https://api-rubtech.designaccentindia.com/Content/Uploads/" +
                            (ad.ImagePath.includes("\\") ? ad.ImagePath.split("\\").pop() : ad.ImagePath.split("/").pop())
                            : null
                    }));
                } else {
                    console.error("Invalid response format:", response.data);
                    $scope.advertisements = [];
                }
            })
            .catch(function (error) {
                console.error("Error fetching advertisements:", error);
            });
    };
    $scope.getAdvertisements();

});