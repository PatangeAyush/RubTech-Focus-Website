﻿var app = angular.module("dashboardApp"); 

app.controller('ContactController', function ($scope, $http) {

    $scope.text = "working";


    // Fetch registered users
    $scope.getContact = function () {
        $http.post('https://api-rubtech.designaccentindia.com/Contact/GetContact')
            .then(function (response) {
                console.log('API Response:', response.data);

                if (Array.isArray(response.data)) {
                    $scope.Contacts = response.data;   /// list 

                    $scope.Contact = $scope.Contacts[0].Contact;
                    $scope.alternateContact = $scope.Contacts[0].Alternative_Contact;
                    $scope.Email = $scope.Contacts[0].Email;
                    $scope.Address = $scope.Contacts[0].Address;

                } else {
                    console.error("Expected an array but received:", response.data);
                    $scope.events = [];
                }
            })
            .catch(function (error) {
                console.error('Error fetching data:', error);
            });
    };


    $scope.getContact();
    
});