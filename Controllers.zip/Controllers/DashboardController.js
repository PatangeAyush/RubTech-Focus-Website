﻿var app = angular.module("dashboardApp"); // Do not redefine []

app.controller('GalleryEventController', function ($scope, $http) {
    $scope.eventTitles = [];

    $scope.getData = function () {
        $http.post('https://api-rubtech.designaccentindia.com/GalleryEvent/GetGallery')
            .then(function (response) {
                console.log('API Response:', response.data);

                if (Array.isArray(response.data) && response.data.length > 0) {
                    $scope.events = response.data;
                    $scope.eventTitles = response.data.map(event => event.Title || "Untitled Event");
                } else {
                    console.error("Invalid response format:", response.data);
                    $scope.eventTitles = [];
                }
            })
            .catch(function (error) {
                console.error('Error fetching data:', error);
                $scope.eventTitles = [];
            });
    };
    $scope.getData();

});