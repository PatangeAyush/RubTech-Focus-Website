﻿var app = angular.module("dashboardApp", []);

app.controller("EventDetailsController", function ($scope, $http) {
    $scope.text = "working";

    // Fetch Event Details
    $scope.getEventDetails = function () {
        $http.post("https://api-rubtech.designaccentindia.com/Event/GetEvents")
            .then(function (response) {
                console.log("API Response:", response.data);

                if (Array.isArray(response.data) && response.data.length > 0) {
                    // Filter only the specific event
                    let filteredEvents = response.data.filter(event =>
                        event.EventTitle === "National Rubber Conference 2023 Kolkata Organized by AIRIA Eastern Region"
                    );

                    if (filteredEvents.length > 0) {
                        let event = filteredEvents[0]; // Take only the first matching event

                        // Extract all unique images from all matching events
                        let imagePaths = [];
                        filteredEvents.forEach(ev => {
                            if (ev.ImagePaths && ev.ImagePaths.length > 0) {
                                ev.ImagePaths.forEach(img => {
                                    let imageUrl = "https://api-rubtech.designaccentindia.com/Content/Uploads/" +
                                        (img.includes("\\") ? img.split("\\").pop() : img.split("/").pop());

                                    if (!imagePaths.includes(imageUrl)) {
                                        imagePaths.push(imageUrl);
                                    }
                                });
                            }
                        });

                        // Store event details (only once) and multiple images
                        $scope.eventDetails = {
                            EventTitle: event.EventTitle,
                            SubTitle: event.SubTitle,
                            Paragraph: event.Paragraph,
                            imagePaths: imagePaths // Store all images without duplicates
                        };
                    } else {
                        $scope.eventDetails = {};
                    }

                    console.log("Filtered Event Details:", $scope.eventDetails);
                } else {
                    console.error("Expected an array but received:", response.data);
                    $scope.eventDetails = {};
                }
            })
            .catch(function (error) {
                console.error("Error fetching event details:", error);
            });
    };

    $scope.getEventDetails();
});
