﻿var app = angular.module("dashboardApp", []);

app.controller('EventsControllers', function ($scope, $http, $location, $window) {
    $scope.events = [];
    $scope.groupedEvents = [];
    $scope.selectedEvent = null;

    // Fetch events from API
    $scope.getEvents = function () {
        $http.post('https://api-rubtech.designaccentindia.com/GalleryEvent/GetGallery')
            .then(function (response) {
                console.log('API Response:', response.data);
                if (Array.isArray(response.data)) {
                    // Map events to a simpler structure
                    $scope.events = response.data.map(function (event) {
                        return {
                            ID: event.ID,
                            Title: event.Title,
                            ImagePaths: event.ImagePaths ? event.ImagePaths.map(function (image) {
                                return 'https://api-rubtech.designaccentindia.com/Content/Uploads/' +
                                    (image.includes('\\') ? image.split('\\').pop() : image.split('/').pop());
                            }) : []
                        };
                    });

                    // Group events by title
                    var groups = {};
                    $scope.events.forEach(function (event) {
                        if (groups[event.Title]) {
                            groups[event.Title].ImagePaths = groups[event.Title].ImagePaths.concat(event.ImagePaths);
                        } else {
                            groups[event.Title] = {
                                Title: event.Title,
                                ImagePaths: event.ImagePaths.slice()
                            };
                        }
                    });

                    // Convert groups object to an array
                    $scope.groupedEvents = Object.keys(groups).map(function (key) {
                        return groups[key];
                    });

                    // Set active tab from URL
                    var titleFromURL = $location.search().title;
                    if (titleFromURL) {
                        var foundEvent = $scope.groupedEvents.find(event => event.Title === titleFromURL);
                        $scope.selectedEvent = foundEvent ? foundEvent : $scope.groupedEvents[0];
                    } else {
                        $scope.selectedEvent = $scope.groupedEvents[0]; // Default selection
                    }
                } else {
                    console.error("Invalid response format:", response.data);
                    $scope.events = [];
                }
            })
            .catch(function (error) {
                console.error('Error fetching events:', error);
            });
    };

    // Change active event & update URL without refreshing
    $scope.changeEvent = function (event) {
        $scope.selectedEvent = event;
        $location.search('title', event.Title);
    };

    $scope.getEvents();

    // Lightbox Open Function

    $scope.lightboxVisible = false;
    $scope.selectedImage = "";
    $scope.currentIndex = 0;
    $scope.imagePaths = [];

    $scope.openLightbox = function (image) {
        if (!$scope.selectedEvent || !$scope.selectedEvent.ImagePaths) {
            console.error("selectedEvent ya ImagePaths undefined hai");
            return;
        }

        $scope.imagePaths = $scope.selectedEvent.ImagePaths; // Saari images ko list me store karega
        $scope.currentIndex = $scope.imagePaths.indexOf(image);

        if ($scope.currentIndex === -1) {
            console.error("Image list me nahi mili");
            return;
        }

        $scope.selectedImage = image;
        $scope.lightboxVisible = true;
        console.log("Lightbox open ho raha hai: ", image);
    };

    // Lightbox Close Function
    $scope.closeLightbox = function () {
        $scope.lightboxVisible = false;
    };

    // Navigate to Previous Image
    $scope.prevImage = function () {
        if ($scope.currentIndex > 0) {
            $scope.currentIndex--;
            $scope.selectedImage = $scope.imagePaths[$scope.currentIndex];
        }
    };

    // Navigate to Next Image
    $scope.nextImage = function () {
        if ($scope.currentIndex < $scope.imagePaths.length - 1) {
            $scope.currentIndex++;
            $scope.selectedImage = $scope.imagePaths[$scope.currentIndex];
        }
    };

    // Watcher to update image paths 
    // Ha ha ha
    $scope.$watch("selectedEvent.ImagePaths", function (newImages) {
        if (newImages) {
            $scope.imagePaths = newImages;
        }
    });
});
