﻿var app = angular.module("dashboardApp");

app.controller('FooterMenuController', function ($scope, $http) {

    $scope.text = "working";
    $scope.aboutCompany = function () {
        $http.post('https://api-rubtech.designaccentindia.com/AboutCompany/GetAboutCompany')
            .then(function (response) {
                console.log('API Response:', response.data);

                if (Array.isArray(response.data)) {
                    $scope.aboutCompanyList = response.data; 

                    if ($scope.aboutCompanyList.length > 0) {
                        let aboutCompany = $scope.aboutCompanyList[0];
                        $scope.CompanyAddress = aboutCompany.CompanyAddress;
                    }
                } else {
                    console.error("Expected an array but received:", response.data);
                    $scope.aboutCompanyList = [];
                }
            })
            .catch(function (error) {
                console.error('Error fetching data:', error);
            });
    };

    $scope.aboutCompany();

});
