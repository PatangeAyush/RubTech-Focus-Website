﻿var app = angular.module("dashboardApp");

app.controller('GalleryEventController', function ($scope, $http) {

    // Initialize events array
    $scope.events = [];

    // Fetch the events
    $scope.getEvents = function () {
        $http.post('https://api-rubtech.designaccentindia.com/GalleryEvent/GetGallery')
            .then(function (response) {
                console.log('API Response:', response.data);

                if (Array.isArray(response.data)) {
                    $scope.events = response.data.map(event => ({
                        ID: event.ID,
                        Title: event.Title,
                        ImagePaths: event.ImagePaths ? event.ImagePaths.map(image => {
                            return 'http://api-test1.designaccentindia.com/Content/Uploads/' +
                                (image.includes('\\') ? image.split('\\').pop() : image.split('/').pop());
                        }) : []
                    }));
                } else {
                    console.error("Invalid response format:", response.data);
                    $scope.events = [];
                }
            })
            .catch(function (error) {
                console.error('Error fetching events:', error);
            });
    };

    $scope.getEvents();

    $scope.submitEventTitle = function () {
        if ($scope.eventTitle && $scope.eventTitle.trim() !== "") {
            var newEvent = {
                Title: $scope.eventTitle
            };

            
            $scope.events.push(newEvent);
            $scope.eventTitle = "";  

            Swal.fire({
                title: "Success!",
                text: "Event Title Submitted Successfully.",
                icon: "success",
                confirmButtonText: "OK"
            }).then(() => {
                console.log("New Event Title Added:", newEvent);
            });
        } else {
            Swal.fire({
                title: "Error!",
                text: "Please enter a valid event title.",
                icon: "error",
                confirmButtonText: "OK"
            });
        }
    };

    $scope.uploadFiles = function (files) {
        if (!files || files.length === 0) {
            console.warn("No files selected.");
            return;
        }

        $scope.$apply(function () { 
            $scope.eventImages = files;
        });

        console.log("Selected Images:", $scope.eventImages);
    };

    $scope.insertImages = function () {

        console.log("Selected Event ID:", $scope.selectedTitle);
        console.log("Selected Event Title:", $scope.selectedTitle);
        console.log("Selected Images:", $scope.eventImages);



        if (!$scope.selectedTitle || !$scope.eventImages || $scope.eventImages.length === 0) {
            Swal.fire({
                title: "Error!",
                text: "Please select an event title and upload images.",
                icon: "error",
                confirmButtonText: "OK"
            });
            return;
        }

        var formData = new FormData();
        formData.append("Title", $scope.selectedTitle.Title)


        for (let i = 0; i < $scope.eventImages.length; i++) {
            formData.append("ImagePaths", $scope.eventImages[i]);
        }

        $http.post('https://api-rubtech.designaccentindia.com/GalleryEvent/AddEvent', formData, {
            transformRequest: angular.identity,
            headers: {
                'Content-Type': undefined,
                'Accept': 'application/json'
            }
        }).then(function (response) {
            console.log("Response:", response.data);

            if (response.data.Message === "Event added successfully") {
                Swal.fire({
                    title: "Success!",
                    text: "Event Inserted Successfully",
                    icon: "success",
                    confirmButtonText: "OK"
                }).then(() => {
                    $scope.getEvents();


                    $scope.selectedTitle = "";
                    $scope.eventImages = [];
                    document.getElementById("eventImage").value = "";
                });
            } else {
                Swal.fire({
                    title: "Error!",
                    text: "Image upload failed. Please try again.",
                    icon: "error",
                    confirmButtonText: "OK"
                });
            }
        }).catch(function (error) {
            console.error("Error inserting event:", error);
            Swal.fire({
                title: "Error!",
                text: "Error inserting event.",
                icon: "error",
                confirmButtonText: "OK"
            });
        });
    };

    $scope.updateEvent = function () {
        $scope.UpdateErrorMessage = "";

        if (!$scope.selectedEvent.Title) {
            $scope.UpdateErrorMessage = "Please enter the event heading.";
            return;
        }

        var eventData = {
            Id: $scope.selectedEvent.Id,
            Title: $scope.selectedEvent.Title.trim()
        };

        console.log("Updating event with data:", eventData);

        $http.post('https://api-rubtech.designaccentindia.com/GalleryEvent/RenameEvent', eventData)
            .then(response => {
                Swal.fire({
                    title: "Success!",
                    text: "Event Updated Successfully",
                    icon: "success",
                    confirmButtonText: "OK"
                }).then(() => {
                    $scope.getEventDetails();
                    $('#addEventtModal').modal('hide');
                });
            })
            .catch(error => {
                console.error("Error updating event:", error);
                Swal.fire({
                    title: "Error!",
                    text: "Error updating event.",
                    icon: "error",
                    confirmButtonText: "OK"
                });
            });
    };

    $scope.addEventModal = function (event) {
        $scope.selectedEvent = {
            Id: event.ID,
            Title: event.Title
        };
        $('#addEventtModal').modal('show');
    };




    $scope.deleteEvent = function ($event, event) {
        Swal.fire({
            title: "Are you sure?",
            text: "You won't be able to recover this report!",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            cancelButtonColor: "#6c757d",
            confirmButtonText: "Yes, delete it!",
            cancelButtonText: "No, cancel!",
        }).then((result) => {
            if (result.isConfirmed) {
                var jdata = { id: event.ID };
                console.log("Deleting event:", jdata);

                $http.post("https://api-rubtech.designaccentindia.com/GalleryEvent/DeleteEvent", jdata)
                    .then(function (response) {
                        console.log("Delete API Response:", response.data);

                        if (response.data.message === "Event deleted successfully.") {
                            Swal.fire({
                                title: "Deleted!",
                                text: "Event has been deleted.",
                                icon: "success",
                            }).then(() => {
                                $scope.getEvents();
                            });
                        } else {
                            Swal.fire("Error", "Unexpected API response: " + response.data, "error");
                        }
                    })
                    .catch(function (error) {
                        console.error("Error deleting event:", error);
                        Swal.fire("Error", "Failed to delete event. Check console for details.", "error");
                    });
            } else {
                Swal.fire("Cancelled", "Event is safe :)", "error");
            }
        });
    };


});
