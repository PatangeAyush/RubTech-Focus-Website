﻿var app = angular.module("dashboardApp"); // Do not redefine []

app.controller('GalleryReportController', function ($scope, $http) {

    $scope.getReports = function () {
        $http.post('https://api-rubtech.designaccentindia.com/GalleryReport/GetGalleryReport')
            .then(function (response) {
                console.log('API Response:', response.data);

                if (Array.isArray(response.data)) {
                    $scope.reports = response.data.map(report => ({
                        ID: report.ID,
                        ReportName: report.ReportName,
                        ImagePaths: report.ImagePaths ? report.ImagePaths.map(image => {
                            return 'http://api-test1.designaccentindia.com/Content/Uploads/' +
                                (image.includes('\\') ? image.split('\\').pop() : image.split('/').pop());
                        }) : []
                    }));
                } else {
                    console.error("Invalid response format:", response.data);
                    $scope.reports = [];
                }
            })
            .catch(function (error) {
                console.error('Error fetching reports:', error);
            });
    };

  
    $scope.getReports();

    $scope.uploadFiles = function (files) {
        if (files.length > 0) {
            $scope.$applyAsync(() => {
                $scope.reportImages = []; 

                for (let i = 0; i < files.length; i++) {
                    $scope.reportImages.push(files[i]); 
                }

                console.log("Selected Images:", $scope.reportImages);
            });
        }
    };

    // Insert Report
    $scope.Insert = function () {
        $scope.ErrorMessage = "";

        if (!$scope.reportTitle) {
            $scope.ErrorMessage = "Please enter the Report Title";
            return false;
        }

        if (!$scope.reportImages || $scope.reportImages.length === 0) {
            $scope.ErrorMessage = "Please upload Report Images.";
            return false;
        }

        var formData = new FormData();
        formData.append("ReportName", $scope.reportTitle);


        for (let i = 0; i < $scope.reportImages.length; i++) {
            formData.append("ImagePaths[]", $scope.reportImages[i]);
        }

        $http.post('https://api-rubtech.designaccentindia.com/GalleryReport/AddGalleryReport', formData, {
            transformRequest: angular.identity,
            headers: {
                'Content-Type': undefined,
                'Accept': 'application/json'
            }
        })
            .then(function (response) {
                console.log("Response:", response.data);

                if (response.data.Messege == "Gallery Report Added Successfully") {
                    Swal.fire({
                        title: "Success!",
                        text: "Report Inserted Successfully",
                        icon: "success",
                        confirmButtonText: "OK"
                    }).then(() => {
                        $scope.getReports(); 

                        // Clear input fields
                        $scope.reportTitle = "";
                        $scope.reportImages = [];
                        document.getElementById("reportImageUpload").value = ""; // Reset file input
                        $scope.$apply(); // Apply changes
                    });
                } else {
                    Swal.fire({
                        title: "Error!",
                        text: "Image upload failed. Please try again.",
                        icon: "error",
                        confirmButtonText: "OK"
                    });
                }
            })
            .catch(function (error) {
                console.error("Error inserting report:", error);
                Swal.fire({
                    title: "Error!",
                    text: "Error inserting report.",
                    icon: "error",
                    confirmButtonText: "OK"
                });
            });
    };


    $scope.updateReport = function () {
        console.log("Selected Report Before Sending:", $scope.selectedReport);

        var jdata = {
            id: $scope.selectedReport.id,
            ReportName: $scope.selectedReport.Title, 
            ImagePaths: $scope.selectedReport.reportImage
        };

        console.log("Data Being Sent to API:", jdata);

        $http.post("https://api-rubtech.designaccentindia.com/GalleryReport/RenameGalleryReport", jdata, {
            headers: {
                "Content-Type": "application/json",
                Accept: "application/json"
            }
        })
            .then(function (response) {
                console.log("API Response:", response.data);

                if (response.data.Messege === "Report Renamed Successfully") {
                    Swal.fire({
                        title: "Success!",
                        text: "Report Updated Successfully",
                        icon: "success",
                        confirmButtonText: "OK"
                    }).then(() => {
                        $scope.getReports(); 
                        $("#addReportModal").modal("hide");  
                    });
                } else {
                    Swal.fire({
                        title: "Error!",
                        text: "Report update failed. Please try again.",
                        icon: "error",
                        confirmButtonText: "OK"
                    });
                }
            })
            .catch(function (error) {
                console.error("Error updating report:", error);
                Swal.fire({
                    title: "Error!",
                    text: "Error updating report.",
                    icon: "error",
                    confirmButtonText: "OK"
                });
            });
    };

    $scope.addReportModal = function (data) {
        console.log("Report Data Received in Modal:", data);

        $scope.selectedReport = {
            id: data.ID,
            Title: data.ReportName,  
            reportImage: data.ImagePaths
        };

        $('#addReportModal').modal('show');  
    };

    $scope.deleteReport = function ($event, report) {
        Swal.fire({
            title: "Are you sure?",
            text: "You won't be able to recover this report!",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            cancelButtonColor: "#6c757d",
            confirmButtonText: "Yes, delete it!",
            cancelButtonText: "No, cancel!",
        }).then((result) => {
            if (result.isConfirmed) {
                var jdata = { id: report.ID };  
                console.log("Deleting report:", jdata);

                $http.post("https://api-rubtech.designaccentindia.com/GalleryReport/DeleteGalleryReport", jdata)
                    .then(function (response) {
                        console.log("Delete API Response:", response.data);

                        if (response.data.Messege === "Report Deleted Successfully") {
                            Swal.fire({
                                title: "Deleted!",
                                text: "Report has been deleted.",
                                icon: "success",
                            }).then(() => {
                                $scope.getReports(); 
                            });
                        } else {
                            Swal.fire("Error", "Unexpected API response: " + response.data, "error");
                        }
                    })
                    .catch(function (error) {
                        console.error("Error deleting report:", error);
                        Swal.fire("Error", "Failed to delete report. Check console for details.", "error");
                    });
            } else {
                Swal.fire("Cancelled", "Report is safe :)", "error");
            }
        });
    };


});
