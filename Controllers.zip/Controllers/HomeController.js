﻿var app = angular.module("dashboardApp");

app.controller("HomeController", function ($scope, $http) {
    $scope.text = "working";
    $scope.messageDetails = {}; // For specific message details
    $scope.reportDetails = {};  // For specific report details
    $scope.advertisements = []; // Store advertisements

    // Function to fetch advertisements
    //$scope.getAdvertisements = function () {
    //    $http.post("https://localhost:44328/Advertisement/GetAdvertisement")
    //        .then(function (response) {
    //            console.log("Advertisements API Response:", response.data);

    //            if (Array.isArray(response.data)) {
    //                $scope.advertisements = response.data.map(ad => ({
    //                    ID: ad.Id,
    //                    URL:ad.URL,
    //                    ImagePath: ad.ImagePath
    //                        ? "https://localhost:44328/Content/Uploads/" +
    //                        (ad.ImagePath.includes("\\") ? ad.ImagePath.split("\\").pop() : ad.ImagePath.split("/").pop())
    //                        : null
    //                }));
    //            } else {
    //                console.error("Invalid response format:", response.data);
    //                $scope.advertisements = [];
    //            }
    //        })
    //        .catch(function (error) {
    //            console.error("Error fetching advertisements:", error);
    //        });
    //};

    $scope.getAdvertisements = function () {
        $http.post("https://api-rubtech.designaccentindia.com/Advertisement/GetAdvertisement")
            .then(function (response) {
                console.log("Advertisements API Response:", response.data);

                if (Array.isArray(response.data)) {
                    $scope.advertisements = response.data.map(ad => ({
                        ID: ad.Id,
                        URL: ad.URL,
                        ImagePath: ad.ImagePath
                            ? "https://api-rubtech.designaccentindia.com/" + ad.ImagePath.replace(/\\/g, "/") // Backslash ko forward slash me convert kiya
                            : null
                    }));
                } else {
                    console.error("Invalid response format:", response.data);
                    $scope.advertisements = [];
                }
            })
            .catch(function (error) {
                console.error("Error fetching advertisements:", error);
            });
    };

    // Function to fetch banners
    $scope.getBanners = function () {
        $http.post('https://api-rubtech.designaccentindia.com/Banner/GetBanner')
            .then(function (response) {
                console.log('Banners API Response:', response.data);
                if (Array.isArray(response.data) && response.data.length > 0) {
                    $scope.banners = response.data;
                    $scope.Banner1 = $scope.banners[0] || {};
                    $scope.BannerImage1 = $scope.Banner1.ImagePath
                        ? 'https://api-rubtech.designaccentindia.com/Content/Uploads/' +
                        ($scope.Banner1.ImagePath.includes('\\') ?
                            $scope.Banner1.ImagePath.split('\\').pop() :
                            $scope.Banner1.ImagePath.split('/').pop())
                        : 'assets/images/default-banner.jpg';
                } else {
                    console.error("Expected an array but received:", response.data);
                    $scope.banners = [];
                }
            })
            .catch(function (error) {
                console.error('Error fetching banner details:', error);
            });
    };

    // Function to fetch technical abstracts
    $scope.getTechnicalAbstracts = function () {
        $http.post('https://api-rubtech.designaccentindia.com/TechnicalAbstract/GetTechnicalAbstracts')
            .then(function (response) {
                console.log('API Response:', response.data);
                if (Array.isArray(response.data)) {
                    $scope.technicalAbstracts = response.data.map(abstract => ({
                        Id: abstract.Id,
                        Name: abstract.Name,
                        Author_Name: abstract.Author_Name,
                        Author_Description: abstract.Author_Description,
                        Abstract_Paragraph: abstract.Abstract_Paragraph,
                        ImageUrl: abstract.Absract_ImagePath
                            ? 'https://api-rubtech.designaccentindia.com/Content/Uploads/' + abstract.Absract_ImagePath.split(/\\|\//).pop()
                            : '',
                        Url: abstract.Url || '#'
                    }));
                } else {
                    console.error("Invalid response format:", response.data);
                    $scope.technicalAbstracts = [];
                }
            })
            .catch(function (error) {
                console.error('Error fetching abstracts:', error);
            });
    };

    // Function to fetch team details
    $scope.getTeamDetails = function () {
        let apiBaseUrl = "https://api-rubtech.designaccentindia.com"; // 👈 API ka base URL define kar diya

        $http.post(apiBaseUrl + '/Mentor/GetMentor') // 👈 API call bhi dynamic base URL ke saath
            .then(function (response) {
                console.log('Team API Response:', response.data);
                if (Array.isArray(response.data)) {
                    $scope.teams = response.data.map(team => {
                        let imagePath = team.ImagePath ? team.ImagePath.replace(/\\/g, '/') : null;

                        return {
                            ID: team.ID,
                            Name: team.Name,
                            Position: team.Position,
                            ImagePath: imagePath
                                ? apiBaseUrl + "/" + imagePath // 👈 Base URL + Relative Path
                                : 'assets/images/default-team.jpg' // 👈 Default image agar null hai
                        };
                    });
                } else {
                    console.error("Invalid response format:", response.data);
                    $scope.teams = [];
                }
            })
            .catch(function (error) {
                console.error('Error fetching team details:', error);
            });
    };


    // Function to fetch all messages
    $scope.getMessageDetails = function () {
        $http.post('https://api-rubtech.designaccentindia.com/Messege/GetMessege')
            .then(function (response) {
                console.log('Messages API Response:', response.data);
                if (Array.isArray(response.data)) {
                    $scope.messages = response.data.map(message => ({
                        ID: message.Id,
                        Name: message.Name,
                        Position: message.Position,
                        Paragraph: message.Paragraph,
                        MessegeFrom: message.MessegeFrom,
                        ImagePath: message.ImagePath
                            ? 'https://api-rubtech.designaccentindia.com/' + message.ImagePath.replace(/\\/g, '/')
                            : 'assets/images/default-message.jpg'
                    }));
                } else {
                    console.error("Invalid response format:", response.data);
                    $scope.messages = [];
                }
            })
            .catch(function (error) {
                console.error('Error fetching message details:', error);
            });
    };

    // Function to fetch all reports
    $scope.getReportDetails = function () {
        $http.post('https://api-rubtech.designaccentindia.com/Report/GetReport')
            .then(function (response) {
                console.log('Reports API Response:', response.data);
                if (Array.isArray(response.data)) {
                    let uniqueReports = {};

                    response.data.forEach(report => {
                        const reportName = report.ReportName.trim().toLowerCase();

                        if (!uniqueReports[reportName]) {
                            uniqueReports[reportName] = {
                                ID: report.ID,
                                ReportName: report.ReportName,
                                ReportSubParagraph: report.ReportSubParagraph,
                                Report_Description: report.Report_Description,
                                ReportImage: report.ReportImage
                                    ? 'https://api-rubtech.designaccentindia.com/Content/Uploads/' +
                                    (report.ReportImage.includes('\\') ? report.ReportImage.split('\\').pop() : report.ReportImage.split('/').pop())
                                    : 'assets/images/default-report.jpg'
                            };
                        }
                    });

                    // Convert object back to array
                    $scope.reports = Object.values(uniqueReports);
                } else {
                    console.error("Invalid response format:", response.data);
                    $scope.reports = [];
                }
            })
            .catch(function (error) {
                console.error('Error fetching report details:', error);
            });
    };
    $scope.getEvents = function () {
        $http.post('https://api-rubtech.designaccentindia.com/Event/GetEvents')
            .then(function (response) {
                console.log('API Response:', response.data);
                if (Array.isArray(response.data)) {
                    let eventsMap = {};

                    response.data.forEach(event => {
                        let titleKey = event.Title.trim(); // Trim spaces for consistency

                        if (!eventsMap[titleKey]) {
                            eventsMap[titleKey] = {
                                title: event.Title,
                                images: [],
                                link: "#"
                            };
                        }

                        // Ensure images are correctly formatted and unique
                        if (event.ImagePaths && event.ImagePaths.length > 0) {
                            event.ImagePaths.forEach(img => {
                                let imageUrl = "https://api-rubtech.designaccentindia.com/Content/Uploads/" +
                                    (img.includes("\\") ? img.split("\\").pop() : img.split("/").pop());

                                if (!eventsMap[titleKey].images.includes(imageUrl)) {
                                    eventsMap[titleKey].images.push(imageUrl);
                                }
                            });
                        }
                    });

                    // Convert to an array
                    $scope.groupedEvents = Object.values(eventsMap);

                    console.log("Grouped Events:", $scope.groupedEvents);
                } else {
                    console.error("Invalid response format:", response.data);
                    $scope.groupedEvents = [];
                }
            })
            .catch(function (error) {
                console.error('Error fetching events:', error);
            });
    };
    $scope.getMagzines = function () {
        $http.post("https://api-rubtech.designaccentindia.com/Magzine/GetMagzine")
            .then(function (response) {
                console.log("API Response:", response.data);

                if (Array.isArray(response.data)) {
                    $scope.magzines = response.data.map(mag => ({
                        ID: mag.Id,
                        ImagePath: mag.ImagePath
                            ? "https://api-rubtech.designaccentindia.com/Content/Uploads/" +
                            (mag.ImagePath.includes("\\") ? mag.ImagePath.split("\\").pop() : mag.ImagePath.split("/").pop())
                            : null
                    }));
                } else {
                    console.error("Invalid response format:", response.data);
                    $scope.magzines = [];
                }
            })
            .catch(function (error) {
                console.error("Error fetching magzines:", error);
            });
    };





    // Call all fetch functions on page load
    $scope.getBanners();
    $scope.getTeamDetails();
    $scope.getMessageDetails();
    $scope.getReportDetails();
    $scope.getTechnicalAbstracts();
    $scope.getAdvertisements(); // Fetch advertisements on load
    $scope.getEvents();
    $scope.getMagzines();
});
