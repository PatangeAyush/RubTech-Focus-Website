﻿var app = angular.module("dashboardApp");

app.controller('HomeEventDetailsController', function ($scope, $http) {
    $scope.text = "working";

    // Function to normalize strings (removes extra spaces, trims, converts to lowercase)
    function normalizeText(text) {
        return text ? text.replace(/\s+/g, " ").trim().toLowerCase() : "";
    }

    // Fetch Event Details
    $scope.getEventDetails = function () {
        $http.post('https://api-rubtech.designaccentindia.com/Event/GetEvents')
            .then(function (response) {
                console.log('API Response:', response.data);

                if (Array.isArray(response.data) && response.data.length > 0) {
                    let eventMap = {};

                    response.data.forEach(event => {
                        // Normalize title, subtitle, and paragraph
                        let normalizedTitle = normalizeText(event.EventTitle);
                        let normalizedSubtitle = normalizeText(event.SubTitle);
                        let normalizedParagraph = normalizeText(event.Paragraph);

                        let key = normalizedTitle + "|" + normalizedSubtitle + "|" + normalizedParagraph;

                        if (!eventMap[key]) {
                            eventMap[key] = {
                                title: event.EventTitle,  // Keep original case for display
                                subtitle: event.SubTitle,
                                paragraph: event.Paragraph,
                                images: [],
                                link: "#",
                            };
                        }

                        // Extract image path and store in images array
                        if (event.ImagePaths && event.ImagePaths.length > 0) {
                            event.ImagePaths.forEach(imagePath => {
                                let formattedPath = 'https://api-rubtech.designaccentindia.com/Content/Uploads/' +
                                    (imagePath.includes('\\') ? imagePath.split('\\').pop() : imagePath.split('/').pop());

                                if (!eventMap[key].images.includes(formattedPath)) {
                                    eventMap[key].images.push(formattedPath);
                                }
                            });
                        }
                    });

                    // Convert eventMap to an array for ng-repeat
                    $scope.events = Object.values(eventMap);
                } else {
                    console.error("Expected an array but received:", response.data);
                    $scope.events = [];
                }
            })
            .catch(function (error) {
                console.error('Error fetching event details:', error);
            });
    };


    $scope.getEventDetails();
});
