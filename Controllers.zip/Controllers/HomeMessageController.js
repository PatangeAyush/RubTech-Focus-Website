﻿var app = angular.module("dashboardApp");

app.controller('HomeMessageController', function ($scope, $http) {

    $scope.text = "Working";

    // Fetch Message Details
    $scope.getMessageDetails = function () {
        $http.post('https://api-rubtech.designaccentindia.com/Messege/GetMessege')
            .then(function (response) {
                console.log('API Response:', response.data);

                if (Array.isArray(response.data)) {
                    $scope.messages = response.data.map(message => ({
                        ID: message.Id,
                        Name: message.Name,
                        Position: message.Position,
                        Paragraph: message.Paragraph,
                        MessegeFrom: message.MessegeFrom,
                        ImagePath: message.ImagePath
                            ? 'http://api-test1.designaccentindia.com/' + message.ImagePath.replace(/\\/g, '/')
                            : null
                    }));
                } else {
                    console.error("Invalid response format:", response.data);
                    $scope.messages = [];
                }
            })
            .catch(function (error) {
                console.error('Error fetching message details:', error);
            });
    };

    // Call API on Controller Load
    $scope.getMessageDetails();

});