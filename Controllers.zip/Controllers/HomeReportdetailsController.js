﻿var app = angular.module("dashboardApp");

app.controller('HomeReportdetailsController', function ($scope, $http) {
    $scope.text = "working";

    // Fetch Report Details
    $scope.getReportDetails = function () {
        $http.post('https://api-rubtech.designaccentindia.com/Report/GetReport')
            .then(function (response) {
                console.log('API Response:', response.data);

                if (Array.isArray(response.data)) {
                    let uniqueReports = {};

                    response.data.forEach(report => {
                        const reportName = report.ReportName.trim().toLowerCase(); // Normalize for consistency

                        if (!uniqueReports[reportName]) {
                            uniqueReports[reportName] = {
                                ID: report.ID,
                                ReportName: report.ReportName,
                                ReportSubParagraph: report.ReportSubParagraph,
                                Report_Description: report.Report_Description,
                                ReportImage: report.ReportImage
                                    ? 'http://api-test1.designaccentindia.com/Content/Uploads/' +
                                    (report.ReportImage.includes('\\') ? report.ReportImage.split('\\').pop() : report.ReportImage.split('/').pop())
                                    : 'assets/images/default-report.jpg' // Default image fallback
                            };
                        }
                    });

                    // Convert object back to array
                    $scope.reports = Object.values(uniqueReports);
                } else {
                    console.error("Invalid response format:", response.data);
                    $scope.reports = [];
                }
            })
            .catch(function (error) {
                console.error('Error fetching report details:', error);
            });
    };

    $scope.getReportDetails();
});
