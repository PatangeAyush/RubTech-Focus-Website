﻿var app = angular.module("dashboardApp"); // Do not redefine []

app.controller("IRMRA-24th-RUBBER-CONFERENCE-EXPO-report", function ($scope, $http) {
    $scope.text = "working";

    // Fetch Report Details
    $scope.getReportDetails = function () {
        $http.post("http://api-test1.designaccentindia.com/Report/GetReport")
            .then(function (response) {
                console.log("API Response:", response.data);

                if (Array.isArray(response.data) && response.data.length > 0) {
                    // Filter reports for the specific event
                    let filteredReports = response.data.filter(report =>
                        report.ReportName === "IRMRA 24th RUBBER CONFERENCE & EXPO"
                    );

                    if (filteredReports.length > 0) {
                        let report = filteredReports[0];

                        let imagePaths = [];
                        filteredReports.forEach(rep => {
                            if (rep.ReportImage) {
                                let imageUrl = "http://api-test1.designaccentindia.com/Content/Uploads/" + rep.ReportImage.split(/[/\\]/).pop();
                                if (!imagePaths.includes(imageUrl)) {
                                    imagePaths.push(imageUrl);
                                }
                            }
                        });

                        // Store event details and images separately
                        $scope.reportDetails = {
                            ReportName: report.ReportName,
                            ReportSubParagraph: report.ReportSubParagraph,
                            Report_Description: report.Report_Description
                        };

                        // Assign images to the correct scope variable
                        $scope.ReportImages = imagePaths;
                    } else {
                        $scope.reportDetails = {};
                        $scope.ReportImages = [];
                    }

                    console.log("Filtered Report Details:", $scope.reportDetails);
                    console.log("Image Paths:", $scope.ReportImages);
                } else {
                    console.error("Expected an array but received:", response.data);
                    $scope.reportDetails = {};
                    $scope.ReportImages = [];
                }
            })
            .catch(function (error) {
                console.error("Error fetching report details:", error);
                $scope.reportDetails = {};
                $scope.ReportImages = [];
            });
    };

    $scope.getReportDetails();
});
