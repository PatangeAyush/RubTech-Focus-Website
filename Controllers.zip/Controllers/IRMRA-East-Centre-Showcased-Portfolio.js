﻿var app = angular.module("dashboardApp", []);

app.controller("IRMRA-East-Centre-Showcased-Portfolio", function ($scope, $http) {
    $scope.text = "working";

    // Fetch Event Details
    $scope.getEventDetails = function () {
        $http.post("http://api-test1.designaccentindia.com/Event/GetEvents")
            .then(function (response) {
                console.log("API Response:", response.data);

                if (Array.isArray(response.data) && response.data.length > 0) {
                    // Filter only the specific event
                    let filteredEvents = response.data.filter(event =>
                        event.EventTitle === "IRMRA East Centre Showcased Portfolio service at 10th IME 2023, Eco Park, Kolkata, WB."
                    );

                    if (filteredEvents.length > 0) {
                        let event = filteredEvents[0];


                        let imagePaths = [];
                        filteredEvents.forEach(ev => {
                            if (ev.ImagePaths && ev.ImagePaths.length > 0) {
                                ev.ImagePaths.forEach(img => {
                                    let imageUrl = "http://api-test1.designaccentindia.com/Content/Uploads/" +
                                        (img.includes("\\") ? img.split("\\").pop() : img.split("/").pop());

                                    if (!imagePaths.includes(imageUrl)) {
                                        imagePaths.push(imageUrl);
                                    }
                                });
                            }
                        });

                        // Store event details (only once) and multiple images
                        $scope.eventDetails = {
                            EventTitle: event.EventTitle,
                            SubTitle: event.SubTitle,
                            Paragraph: event.Paragraph,
                            imagePaths: imagePaths // Store all images without duplicates
                        };
                    } else {
                        $scope.eventDetails = {};
                    }

                    console.log("Filtered Event Details:", $scope.eventDetails);
                } else {
                    console.error("Expected an array but received:", response.data);
                    $scope.eventDetails = {};
                }
            })
            .catch(function (error) {
                console.error("Error fetching event details:", error);
            });
    };

    $scope.getEventDetails();
});
