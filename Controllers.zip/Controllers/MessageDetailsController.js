﻿var app = angular.module("dashboardApp", []);

app.controller('MessageDetailsController', function ($scope, $http, $location) {
    $scope.messageDetails = {};

    // Function to get URL parameters
    function getQueryParam(param) {
        var searchParams = new URLSearchParams(window.location.search);
        return searchParams.get(param);
    }

    var messageId = getQueryParam('id'); // Get ID from URL

    if (messageId) {
        // Fetch all messages
        $http.post('https://api-rubtech.designaccentindia.com/Messege/GetMessege')
            .then(function (response) {
                console.log('API Response:', response.data);

                if (Array.isArray(response.data)) {
                    var foundMessage = response.data.find(m => m.Id == messageId);
                    if (foundMessage) {
                        $scope.messageDetails = {
                            ID: foundMessage.Id,
                            Name: foundMessage.Name,
                            Position: foundMessage.Position,
                            Paragraph: foundMessage.Paragraph,
                            MessegeFrom: foundMessage.MessegeFrom,

                            // Fetch Image
                            ImagePath: foundMessage.ImagePath
                                ? 'https://api-rubtech.designaccentindia.com/' + foundMessage.ImagePath.replace(/\\/g, '/')
                                : 'assets/images/default.jpg' // Default fallback image
                        };
                    } else {
                        console.error("Message not found with ID:", messageId);
                    }
                }
            })
            .catch(function (error) {
                console.error('Error fetching message details:', error);
            });
    } else {
        console.warn("No message ID found in URL");
    }
});
