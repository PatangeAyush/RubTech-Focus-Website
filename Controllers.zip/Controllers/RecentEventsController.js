﻿var app = angular.module("dashboardApp"); // Do not redefine []

app.controller('RecentEventsController', function ($scope, $http, $timeout) { // Added $timeout dependency

    $scope.working = "text";
    $scope.recentEvents = [];
    $scope.magzines = [];

    // ✅ Fetch Recent Events
    $scope.getEventDetails = function () {
        $http.post('https://api-rubtech.designaccentindia.com/Event/GetEvents')
            .then(function (response) {
                console.log('Event API Response:', response.data);

                if (Array.isArray(response.data)) {
                    const uniqueEventsMap = {};
                    const uniqueEvents = [];

                    response.data.forEach(event => {
                        if (event.EventTitle && !uniqueEventsMap[event.EventTitle]) {
                            uniqueEventsMap[event.EventTitle] = true;

                            const imageName = event.ImagePaths && event.ImagePaths.length > 0
                                ? (event.ImagePaths[0].includes('\\') ? event.ImagePaths[0].split('\\').pop() : event.ImagePaths[0].split('/').pop())
                                : null;

                            uniqueEvents.push({
                                ID: event.ID,
                                EventTitle: event.EventTitle,
                                SubTitle: event.SubTitle,
                                Paragraph: event.Paragraph,
                                ImageUrl: imageName
                                    ? 'https://api-rubtech.designaccentindia.com/Content/Uploads/' + imageName
                                    : 'assets/images/no-image.jpg'
                            });
                        }
                    });

                    $scope.recentEvents = uniqueEvents;
                } else {
                    console.error("Invalid response format for events:", response.data);
                }
            })
            .catch(function (error) {
                console.error('Error fetching event details:', error);
            });
    };

    // ✅ Load Event Details on Click
    $scope.loadEventDetails = function (event) {
        console.log('Event clicked:', event);
        window.location.href = 'event-details.html?EventTitle=' + encodeURIComponent(event.EventTitle);
    };

    // ✅ Fetch Magazines
    $scope.getMagzines = function () {
        $http.post("https://api-rubtech.designaccentindia.com/Magzine/GetMagzine")
            .then(function (response) {
                console.log("Magazine API Response:", response.data);

                if (Array.isArray(response.data) && response.data.length > 0) {
                    $scope.magzines = response.data.map(mag => {
                        const imageName = mag.ImagePath
                            ? (mag.ImagePath.includes("\\") ? mag.ImagePath.split("\\").pop() : mag.ImagePath.split("/").pop())
                            : null;

                        const finalImagePath = imageName ? "https://api-rubtech.designaccentindia.com/Content/Uploads/" + imageName : null;
                        console.log('Final Magazine Image Path:', finalImagePath);

                        return {
                            ID: mag.Id,
                            ImagePath: finalImagePath
                        };
                    });

                    // ✅ Initialize Owl Carousel AFTER DOM is ready
                    $timeout(function () {
                        if ($('.widget-post-slider-wrap').hasClass('owl-loaded')) {
                            $('.widget-post-slider-wrap').trigger('destroy.owl.carousel').removeClass('owl-loaded');
                            $('.widget-post-slider-wrap').find('.owl-stage-outer').children().unwrap();
                        }

                        $(".widget-post-slider-wrap").owlCarousel({
                            loop: true,
                            margin: 10,
                            nav: true,
                            autoplay: true,
                            autoplayTimeout: 3000,
                            dots: false,
                            navText: ["‹", "›"],
                            responsive: {
                                0: { items: 1 },
                                600: { items: 2 },
                                1000: { items: 3 }
                            }
                        });
                    }, 500); // Sufficient timeout to allow ng-repeat to finish rendering
                } else {
                    console.error("No magazines found or invalid response.");
                }
            })
            .catch(function (error) {
                console.error("Error fetching magazines:", error);
            });
    };

    $scope.getEventDetails();
    $scope.getMagzines();

});
