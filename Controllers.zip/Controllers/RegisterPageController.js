﻿
var app = angular.module("dashboardApp", []);

app.controller("RegisterPageController", function ($scope, $http) {

    $scope.ErrorMessage = "";


    $scope.sameAsDelivery = false;
    $scope.$watch('sameAsDelivery', function (newValue) {
        if (newValue) {
            $scope.billAddress = $scope.delAddress;
            $scope.bilCity = $scope.delCity;
            $scope.bilPostalCode = $scope.delPostalCode;
            $scope.bilCountry = $scope.delCountry;
        } else {
            $scope.billAddress = '';
            $scope.bilCity = '';
            $scope.bilPostalCode = '';
            $scope.bilCountry = '';
        }
    });


    $scope.register = function () {
        $scope.ErrorMessage = "";

        // Regex patterns
        var emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
        var phonePattern = /^[6-9]\d{9}$/;

        // ---------- FIELD VALIDATIONS ----------
        if (!$scope.fullName) {
            $scope.ErrorMessage = "Please enter the Full Name";
            return false;
        }
        if (!$scope.company) {
            $scope.ErrorMessage = "Please enter the Company Name";
            return false;
        }
        if (!$scope.emailId) {
            $scope.ErrorMessage = "Please enter your Email ID";
            return false;
        }
        if (!emailPattern.test($scope.emailId)) {
            $scope.ErrorMessage = "Please enter a valid Email ID";
            return false;
        }
        if (!$scope.phoneNo) {
            $scope.ErrorMessage = "Please enter your Phone Number";
            return false;
        }
        if (!phonePattern.test($scope.phoneNo)) {
            $scope.ErrorMessage = "Please enter a valid 10-digit Phone Number";
            return false;
        }
        if (!$scope.rdosubscription) {
            $scope.ErrorMessage = "Please select Magazine Subscription";
            return false;
        }
        if (!$scope.subDuration) {
            $scope.ErrorMessage = "Please select Subscription Duration";
            return false;
        }

        // If subscription is not Digital, delivery address is mandatory
        if ($scope.rdosubscription !== "Digital") {
            if (!$scope.delAddress) {
                $scope.ErrorMessage = "Please enter Mailing Address";
                return false;
            }
            if (!$scope.delCity) {
                $scope.ErrorMessage = "Please enter City / State";
                return false;
            }
            if (!$scope.delPostalCode) {
                $scope.ErrorMessage = "Please enter Zip / Postal Code";
                return false;
            }
            if (!$scope.delCountry) {
                $scope.ErrorMessage = "Please enter your Country";
                return false;
            }
        }

        // Billing address validations (only if "Same as Delivery" not checked)
        if (!$scope.sameAsDelivery) {
            if (!$scope.billAddress) {
                $scope.ErrorMessage = "Please enter Billing Address";
                return false;
            }
            if (!$scope.bilCity) {
                $scope.ErrorMessage = "Please enter City / State for Billing";
                return false;
            }
            if (!$scope.bilPostalCode) {
                $scope.ErrorMessage = "Please enter Zip / Postal Code for Billing";
                return false;
            }
            if (!$scope.bilCountry) {
                $scope.ErrorMessage = "Please enter your Billing Country";
                return false;
            }
        }

        // Payment, promotion, membership, and terms validation
        if (!$scope.formData || !$scope.formData.paymentMethod) {
            $scope.ErrorMessage = "Please select Payment Method";
            return false;
        }
        if (!$scope.formData.promotionPreference) {
            $scope.ErrorMessage = "Do you want to continue receiving promotional offers & latest updates? Please select Yes or No!";
            return false;
        }
        if (!$scope.formData.membershipStatus) {
            $scope.ErrorMessage = "Please select IRMRA Membership Status";
            return false;
        }
        if (!$scope.formData.agreeTerms) {
            $scope.ErrorMessage = "Please agree to the Terms & Conditions";
            return false;
        }

        // ---------- DATA PREPARATION ----------
        var jdata = {
            name: $scope.fullName,
            company: $scope.company,
            email: $scope.emailId,
            phoneNumber: $scope.phoneNo,
            Country: $scope.delCountry,
            City_State: $scope.delCity,
            Address: $scope.billAddress,
            magazine: $scope.rdosubscription,
            duration: $scope.subDuration,
            Zip_Postal: $scope.delPostalCode,
            Payment_Info: $scope.formData.paymentMethod,
            Promotional_Preference: $scope.formData.promotionPreference,
            IRMRA_Membership: $scope.formData.membershipStatus
        };

        console.log("Data to be submitted:", jdata);

        // ---------- API CALL ----------
        $http.post('https://api-rubtech.designaccentindia.com/Register/AddUser', jdata)
            .then(function (response) {
                console.log("Response:", response);
                Swal.fire({
                    title: "Success!",
                    text: "Registration Completed Successfully",
                    icon: "success",
                    confirmButtonText: "OK"
                }).then(() => {
                    location.reload();
                });
            })
            .catch(function (error) {
                console.error("Error inserting user:", error);
                Swal.fire({
                    title: "Error!",
                    text: "There was an error during registration. Please try again.",
                    icon: "error",
                    confirmButtonText: "OK"
                });
            });
    };
});
