﻿var app = angular.module("dashboardApp"); // Do not redefine []

app.controller('ReportdetailsController', function ($scope, $http) {


    $scope.text = "working";
    // Fetch Report Details
    $scope.getReportDetails = function () {
        $http.post('https://api-rubtech.designaccentindia.com/Report/GetReport')
            .then(function (response) {
                console.log('API Response:', response.data);

                if (Array.isArray(response.data) && response.data.length > 0) {
                    $scope.reports = response.data; // Store full list of reports

                    // Assign first report details to scope variables
                    $scope.ReportName = $scope.reports[0].ReportName;
                    $scope.ReportSubParagraph = $scope.reports[0].ReportSubParagraph;
                    $scope.Report_Description = $scope.reports[0].Report_Description;
                    $scope.ReportImage = $scope.reports[0].ReportImage
                        ? 'http://api-test1.designaccentindia.com/Content/Uploads/' +
                        ($scope.reports[0].ReportImage.includes('\\')
                            ? $scope.reports[0].ReportImage.split('\\').pop()
                            : $scope.reports[0].ReportImage.split('/').pop())
                        : null;
                } else {
                    console.error("Expected an array but received:", response.data);
                    $scope.reports = [];
                }
            })
            .catch(function (error) {
                console.error('Error fetching report details:', error);
            });
    };

    $scope.getReportDetails();

});
