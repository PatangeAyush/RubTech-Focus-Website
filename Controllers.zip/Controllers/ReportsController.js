﻿var app = angular.module("dashboardApp", []);

app.controller('ReportsController', function ($scope, $http, $location) {
    $scope.reports = [];
    $scope.groupedReports = [];
    $scope.selectedReport = null;

    // Fetch reports from API
    $scope.getReports = function () {
        $http.post('https://api-rubtech.designaccentindia.com/GalleryReport/GetGalleryReport')
            .then(function (response) {
                console.log('API Response:', response.data);
                if (Array.isArray(response.data)) {
                    // Map reports to a simpler structure
                    $scope.reports = response.data.map(function (report) {
                        return {
                            ID: report.ID, // Store ID for query string
                            Title: report.ReportName, // Use ReportName instead of Title
                            ImagePaths: report.ImagePaths ? report.ImagePaths.map(function (image) {
                                return 'https://api-rubtech.designaccentindia.com/Content/Uploads/' +
                                    (image.includes('\\') ? image.split('\\').pop() : image.split('/').pop());
                            }) : []
                        };
                    });

                    // Group reports by ID (so the query string can use ID instead of title)
                    var groups = {};
                    $scope.reports.forEach(function (report) {
                        if (groups[report.ID]) {
                            groups[report.ID].ImagePaths = groups[report.ID].ImagePaths.concat(report.ImagePaths);
                        } else {
                            groups[report.ID] = {
                                ID: report.ID,
                                Title: report.Title,
                                ImagePaths: report.ImagePaths.slice()
                            };
                        }
                    });

                    // Convert groups object to an array
                    $scope.groupedReports = Object.keys(groups).map(function (key) {
                        return groups[key];
                    });

                    // Set active tab based on ID from URL
                    var idFromURL = $location.search().id;
                    if (idFromURL) {
                        var foundReport = $scope.groupedReports.find(report => report.ID == idFromURL);
                        $scope.selectedReport = foundReport ? foundReport : $scope.groupedReports[0];
                    } else {
                        $scope.selectedReport = $scope.groupedReports[0]; // Default selection
                    }
                } else {
                    console.error("Invalid response format:", response.data);
                    $scope.reports = [];
                }
            })
            .catch(function (error) {
                console.error('Error fetching reports:', error);
            });
    };

    // Change active report & update URL with ID instead of title
    $scope.changeReport = function (report) {
        $scope.selectedReport = report;
        $location.search('id', report.ID); // Update URL with ID
    };

    $scope.getReports();

    $scope.lightboxVisible = false;
    $scope.selectedImage = "";
    $scope.currentIndex = 0;
    $scope.imagePaths = [];

    // Lightbox Open Function
    $scope.openLightbox = function (image) {
        if (!$scope.selectedReport || !$scope.selectedReport.ImagePaths) {
            console.error("selectedReport ya ImagePaths undefined hai");
            return;
        }

        $scope.imagePaths = $scope.selectedReport.ImagePaths; // Saari images ko list me store karega
        $scope.currentIndex = $scope.imagePaths.indexOf(image);

        if ($scope.currentIndex === -1) {
            console.error("Image list me nahi mili");
            return;
        }

        $scope.selectedImage = image;
        $scope.lightboxVisible = true;
        console.log("Lightbox open ho raha hai: ", image);
    };

    // Lightbox Close Function
    $scope.closeLightbox = function () {
        $scope.lightboxVisible = false;
    };

    // Navigate to Previous Image
    $scope.prevImage = function () {
        if ($scope.currentIndex > 0) {
            $scope.currentIndex--;
            $scope.selectedImage = $scope.imagePaths[$scope.currentIndex];
        }
    };

    // Navigate to Next Image
    $scope.nextImage = function () {
        if ($scope.currentIndex < $scope.imagePaths.length - 1) {
            $scope.currentIndex++;
            $scope.selectedImage = $scope.imagePaths[$scope.currentIndex];
        }
    };

    // Watcher to update image paths
    $scope.$watch("selectedReport.ImagePaths", function (newImages) {
        if (newImages) {
            $scope.imagePaths = newImages;
        }
    });

});
