﻿var app = angular.module("dashboardApp", []); // Ensure module is created

app.controller('TechnicalAbstractController', function ($scope, $http) {
    $scope.technicalAbstracts = [];
    $scope.groupedAbstracts = [];

    // Fetch the technical abstracts from the API
    $scope.getTechnicalAbstracts = function () {
        $http.post('https://api-rubtech.designaccentindia.com/TechnicalAbstract/GetTechnicalAbstracts')
            .then(function (response) {
                console.log('API Response:', response.data);
                if (Array.isArray(response.data)) {
                    $scope.technicalAbstracts = response.data.map(function (abstract) {
                        return {
                            Id: abstract.Id,
                            Name: abstract.Name,
                            Author_Name: abstract.Author_Name,
                            Author_Description: abstract.Author_Description,
                            Abstract_Paragraph: abstract.Abstract_Paragraph,
                            ImageUrl: abstract.Absract_ImagePath
                                ? 'https://api-rubtech.designaccentindia.com/Content/Uploads/' + abstract.Absract_ImagePath.split(/\\|\//).pop() : '',
                            Url: abstract.Url || '#'
                        };
                    });
                } else {
                    console.error("Invalid response format:", response.data);
                    $scope.technicalAbstracts = [];
                }
            })
            .catch(function (error) {
                console.error('Error fetching abstracts:', error);
            });
    };

   

    $scope.getTechnicalAbstracts();

    // Reports
});
