﻿var app = angular.module("dashboardApp", []);

app.controller('TechnicalAbstractDetailsController', function ($scope, $http) {
    $scope.technicalAbstract = {};
    $scope.technicalAbstracts = [];
    $scope.magzines = [];

    // Function to get URL parameters
    function getQueryParam(param) {
        var searchParams = new URLSearchParams(window.location.search);
        return searchParams.get(param);
    }

    var abstractId = getQueryParam('id'); // Get ID from URL

    // 🔹 Function to Fetch a Specific Technical Abstract (Based on URL ID)
    $scope.getTechnicalAbstractById = function () {
        if (abstractId) {
            $http.post('https://api-rubtech.designaccentindia.com/TechnicalAbstract/GetTechnicalAbstracts')
                .then(function (response) {
                    console.log('Technical Abstract API Response:', response.data);
                    if (Array.isArray(response.data)) {
                        var foundAbstract = response.data.find(a => a.Id == abstractId);
                        if (foundAbstract) {
                            $scope.technicalAbstract = {
                                Id: foundAbstract.Id,
                                Name: foundAbstract.Name,
                                Author_Name: foundAbstract.Author_Name,
                                Author_Description: foundAbstract.Author_Description,
                                Abstract_Paragraph: foundAbstract.Abstract_Paragraph,

                                // Fetch Abstract Image
                                ImageUrl: foundAbstract.Absract_ImagePath
                                    ? 'https://api-rubtech.designaccentindia.com/Content/Uploads/' + foundAbstract.Absract_ImagePath.split(/\\|\//).pop()
                                    : 'assets/images/default-thumbnail.jpg', // Fallback image

                                // Fetch Author Image
                                Author_ImageUrl: foundAbstract.Author_ImagePath
                                    ? 'https://api-rubtech.designaccentindia.com/Content/Uploads/' + foundAbstract.Author_ImagePath.split(/\\|\//).pop()
                                    : 'assets/images/default-author.png', // Fallback image
                            };
                        } else {
                            console.error("Abstract not found with ID:", abstractId);
                        }
                    }
                })
                .catch(function (error) {
                    console.error('Error fetching abstract details:', error);
                });
        }
    };

    // 🔹 Function to Fetch All Technical Abstracts
    $scope.getAllTechnicalAbstracts = function () {
        $http.post('https://api-rubtech.designaccentindia.com/TechnicalAbstract/GetTechnicalAbstracts')
            .then(function (response) {
                console.log('All Technical Abstracts API Response:', response.data);
                if (Array.isArray(response.data)) {
                    $scope.technicalAbstracts = response.data.map(abstract => ({
                        Id: abstract.Id,
                        Title: abstract.Name,
                        Author_Name: abstract.Author_Name,
                        AuthorLink: 'author-profile.html?name=' + encodeURIComponent(abstract.Author_Name),
                        Link: 'technical-abstract-details.html?id=' + abstract.Id,
                        ImageUrl: abstract.Absract_ImagePath
                            ? 'https://api-rubtech.designaccentindia.com/Content/Uploads/' + abstract.Absract_ImagePath.split(/\\|\//).pop()
                            : 'assets/images/default-thumbnail.jpg' // Fallback image
                    }));
                }
            })
            .catch(function (error) {
                console.error('Error fetching technical abstracts:', error);
            });
    };

    // 🔹 Function to Fetch Magazines
    $scope.getMagzines = function () {
        $http.post("https://api-rubtech.designaccentindia.com/Magzine/GetMagzine")
            .then(function (response) {
                console.log("Magzine API Response:", response.data);

                if (Array.isArray(response.data)) {
                    $scope.magzines = response.data.map(mag => ({
                        ID: mag.Id,
                        ImagePath: mag.ImagePath
                            ? "https://api-rubtech.designaccentindia.com/Content/Uploads/" +
                            (mag.ImagePath.includes("\\") ? mag.ImagePath.split("\\").pop() : mag.ImagePath.split("/").pop())
                            : null
                    }));

                    // Initialize Owl Carousel AFTER images are loaded
                    $timeout(function () {
                        $(".widget-post-slider-wrap").owlCarousel('destroy'); // Destroy previous instances
                        $(".widget-post-slider-wrap").owlCarousel({
                            loop: true,
                            margin: 10,
                            nav: true,
                            autoplay: true,
                            autoplayTimeout: 3000,
                            dots: false,
                            navText: ["‹", "›"],
                            responsive: {
                                0: { items: 1 },
                                600: { items: 2 },
                                1000: { items: 3 }
                            }
                        });
                    }, 500); // Wait for Angular to render the images
                } else {
                    console.error("Invalid response format:", response.data);
                    $scope.magzines = [];
                }
            })
            .catch(function (error) {
                console.error("Error fetching magazines:", error);
            });
    };

    $scope.getMagzines(); // Load magazines on controller initialization
    $scope.getTechnicalAbstractById();
    $scope.getAllTechnicalAbstracts();
    $scope.getMagzines();
});
