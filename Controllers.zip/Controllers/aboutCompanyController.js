﻿var app = angular.module("dashboardApp");

app.controller('aboutCompanyController', function ($scope, $http) {

    $scope.text = "working";

    $scope.getData = function () {
        $http.post('https://api-rubtech.designaccentindia.com/AboutCompany/GetAboutCompany')
            .then(function (response) {
                console.log('API Response:', response.data);

                if (Array.isArray(response.data) && response.data.length > 0) {
                    let aboutCompany = response.data[0]; 

                    $scope.CompanyAddress = aboutCompany.CompanyAddress;
                } else {
                    console.error("Expected an array but received:", response.data);
                    $scope.CompanyName = "";
                    $scope.CompanyAddress = "";
                }
            })
            .catch(function (error) {
                console.error('Error fetching data:', error);
            });
    };

    $scope.getData();

});
