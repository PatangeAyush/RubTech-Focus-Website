﻿var app = angular.module("dashboardApp");

app.controller('bannerController', function ($scope, $http) {

    $scope.text = "working";

 
    $scope.getBanners = function () {
        $http.post('https://api-rubtech.designaccentindia.com/Banner/GetBanner')
            .then(function (response) {
                console.log('API Response:', response.data);
                if (Array.isArray(response.data) && response.data.length > 0) {
                    $scope.banners = response.data; 

                    $scope.Banner1 = $scope.banners[0] || {}; 
                   
                    $scope.BannerImage1 = $scope.Banner1.ImagePath
                        ? 'http://api-test1.designaccentindia.com/Content/Uploads/' +
                        ($scope.Banner1.ImagePath.includes('\\') ?
                            $scope.Banner1.ImagePath.split('\\').pop() :
                            $scope.Banner1.ImagePath.split('/').pop())
                        : null;

                } else {
                    console.error("Expected an array but received:", response.data);
                    $scope.banners = [];
                }
            })
            .catch(function (error) {
                console.error('Error fetching banner details:', error);
            });
    };

    $scope.getBanners(); 

});
