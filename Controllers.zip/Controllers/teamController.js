﻿var app = angular.module("dashboardApp");

app.controller('teamController', function ($scope, $http) {
    $scope.text = "working";
    $scope.getTeamDetails = function () {
        $http.post('https://api-rubtech.designaccentindia.com/Mentor/GetMentor')
            .then(function (response) {
                console.log('API Response:', response.data);

                if (Array.isArray(response.data)) {
                    $scope.teams = response.data.map(team => ({
                        ID: team.ID,
                        Name: team.Name,
                        Position: team.Position,
                        ImagePath: team.ImagePath
                            ? 'http://api-test1.designaccentindia.com/' + team.ImagePath.replace(/\\/g, '/')
                            : null
                    }));
                } else {
                    console.error("Invalid response format:", response.data);
                    $scope.teams = [];
                }
            })
            .catch(function (error) {
                console.error('Error fetching team details:', error);
            });
    };

    $scope.getTeamDetails();

});